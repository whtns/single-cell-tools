# single-cell-tools 

![](https://github.com/whtns/single-cell-tools/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/whtns/single-cell-tools/branch/main/graph/badge.svg)](https://codecov.io/gh/whtns/single-cell-tools) [![Deploy](https://github.com/whtns/single-cell-tools/actions/workflows/deploy.yml/badge.svg)](https://github.com/whtns/single-cell-tools/actions/workflows/deploy.yml) [![Documentation Status](https://readthedocs.org/projects/single-cell-tools/badge/?version=latest)](https://single-cell-tools.readthedocs.io/en/latest/?badge=latest)

A package for pseudotime and dimension reduction by cluster centroids

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ single-cell-tools
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://single-cell-tools.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/whtns/single-cell-tools/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
