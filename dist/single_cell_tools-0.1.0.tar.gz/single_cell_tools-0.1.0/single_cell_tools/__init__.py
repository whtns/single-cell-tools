# -*- coding: utf-8 -*-

"""Top-level package for single_cell_tools."""

__author__ = """Kevin Stachelek"""
__email__ = 'kevin.stachelek@gmail.com'
__version__ = '0.1.0'
